> [!IMPORTANT]
> ## 🚀 [Cosmos 3 Has Arrived](https://github.com/NVIDIA/Cosmos)
>
> Cosmos 3 is NVIDIA's next-generation foundation model platform for Physical AI. Compared with Cosmos-Predict2.5, Cosmos 3 delivers significantly stronger world prediction capabilities, producing more accurate, coherent, and physically grounded future-state predictions across a wide range of environments and embodiments.
>
> Beyond improving prediction quality, Cosmos 3 unifies capabilities that previously required multiple specialized models. A single Cosmos 3 model can reason, predict future world states, transfer across domains and modalities, and generate actions and policies for embodied agents within one unified architecture.
>
> This repository is no longer under active development and will receive only limited maintenance updates. Future model releases, features, documentation, and community support will be focused on Cosmos 3.
>
> 👉 Visit the new Cosmos home: https://github.com/NVIDIA/Cosmos
>
> There you will find the latest Cosmos 3 models, technical reports, tutorials, benchmarks, and ecosystem updates.
>
> Thank you for your support of Cosmos-Predict2.5. We encourage all users to migrate to Cosmos 3 for the latest state-of-the-art Physical AI capabilities.

# Imaginaire Attention Subpackage Docs

* [Basic API & Intro](../README.md)
* Docs (you are here)
    * [Backends](backends.md)
    * Features
        * [Basic features](features.md)
        * [Multi-dimensional Attention](multi-dim.md)
            * [Spatio-Temporal Attention](multi-dim.md#spatio-temporal-attention)
    * [APIs](apis.md)
